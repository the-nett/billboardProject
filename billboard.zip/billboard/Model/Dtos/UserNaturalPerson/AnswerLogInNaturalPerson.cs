﻿using billboard.Model.Dtos.UserNaturalPerson;

namespace billboard.Model.Dtos.NaturalPerson
{
    public class AnswerLogInNaturalPerson
    {
        public UserLoginDto Usser {  get; set; }
        public string Token { get; set; }
    }
}

﻿namespace billboard.Model.Dtos.UserTypeXPermissions
{
    public class UserType_PermissionsDto
    {
        public int Id_permission { get; set; }
        public int Id_Usertype { get; set; }
        public bool StateDelete { get; set; }
    }
}

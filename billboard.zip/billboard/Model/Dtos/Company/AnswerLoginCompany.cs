﻿using billboard.Model.Dtos.UserNaturalPerson;

namespace billboard.Model.Dtos.Company
{
    public class AnswerLoginCompany
    {
        public AnswerCompanyLoginDto company { get; set; }
        public string Token { get; set; }
    }
}

﻿namespace billboard.Model.Dtos.Company
{
    public class AnswerCompanyLoginDto
    {
        public int IdCompany { get; set; }
        public required string Company_Name { get; set; }
        public required string Corporate_Email { get; set; }
    }
}

﻿namespace billboard.Model.Dtos.Lessor
{
    public class LessorDto
    {
        public int IdLessor { get; set; }

        public int IdUser { get; set; }

        public int IdUserType { get; set; }

        public bool StateDelete { get; set; }
    }
}

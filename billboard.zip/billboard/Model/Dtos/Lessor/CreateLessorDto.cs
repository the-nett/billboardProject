﻿namespace billboard.Model.Dtos.Lessor
{
    public class CreateLessorDto
    {
        public int IdUser { get; set; }

        public int IdUserType { get; set; }

        public bool StateDelete { get; set; }
    }
}
